Impportand !

-	The program is detecting the directory where it's runs ("bin\debug\") and 
	searching for file there so if you change any *.xml file you will need to 
	copy it to the "bin\debug\" directory and overwrite the old one's.
	
-	Though the program doesn't need the agent if you want to run it with the 
	agent you will need to copy it also to the "bin\debug\" directory.
	i've encluded it only in the SR_demo.zip (saving space) it could be found also
	in the "windows\msagent\chars" or download it from microsoft site.
	